"""Extract data on near-Earth objects and close approaches from CSV and JSON files.

The `load_neos` function extracts NEO data from a CSV file, formatted as
described in the project instructions, into a collection of `NearEarthObject`s.

The `load_approaches` function extracts close approach data from a JSON file,
formatted as described in the project instructions, into a collection of
`CloseApproach` objects.

The main module calls these functions with the arguments provided at the command
line, and uses the resulting collections to build an `NEODatabase`.

You'll edit this file in Task 2.
"""
import csv
import json

from models import NearEarthObject, CloseApproach


def load_neos(neo_csv_path):
    """Read near-Earth object information from a CSV file.

    :param neo_csv_path: A path to a CSV file containing data about near-Earth objects.
    :return: A collection of `NearEarthObject`s.
    """
    # TODO: Load NEO data from the given CSV file.
    with open(neo_csv_path) as f:
        list_=[]
        reader=csv.DictReader(f)
        
        for val in reader:
            a=None
            #print(val)
            if val["pha"]=='N':
                a=False
            else:
                a=True
           # if True:
            #    break
            list_.append(NearEarthObject(val["pdes"],val["name"],val["diameter"],a))
 #def __init__(self, designation,name,diameter,hazardous):        
    
    return list_

list_=load_neos("data/neos.csv")
#print(list_[0].__repr__)

def to_dict(cad_json_path):
    dict_={}
    with open(cad_json_path) as f:
        contents=json.load(f)
        #print(len(contents["data"]))
        for val in contents["data"]:
            if val[0] not in dict_:
                dict_[val[0]]=[[val[3],val[4],val[7]]]
            else:
                dict_[val[0]].append([val[3],val[4],val[7]])
    return dict_
#print(to_dict("data/cad.json"))

def create_collection(object_):
    dict_=to_dict("data/cad.json")
    list_=[]
    for val in dict_[object_.designation]:
        #print(dict_[object_.designation])
        list_.append(CloseApproach(object_.designation,val[0],val[1],val[2],object_))
    return list_   
def combined(list_):
    count=0
    for val in list_:
        print(create_collection(val))
        count+=1
        if(count==10):
            break
#combined_=load_neos("data/neos.csv")
#combined(combined_)
#for val in combined_:
   # print(val.approaches)
        

def load_approaches(cad_json_path):
    """Read close approach data from a JSON file.

    :param neo_csv_path: A path to a JSON file containing data about close approaches.
    :return: A collection of `CloseApproach`es.
    """
    new_list=[]
    with open(cad_json_path) as f:
        contents=json.load(f)
        neo_default=NearEarthObject( "default","default","0",False)
        for val_ in contents["data"]:
            new_list.append(CloseApproach(val_[0],val_[3],val_[4],val_[7],neo_default))
    return new_list
       # __init__(self,designation, time ,distance,velocity,object_):
    
    # TODO: Load close approach data from the given JSON file.
   #return new_list
#print(load_approaches("data/cad.json"))
#list_=load_approaches("data/cad.json")